# Schema

<iframe width="560" height="315" src='https://dbdiagram.io/e/671ca45f97a66db9a3565024/67286f14e9daa85aca33c5b1'> </iframe>

